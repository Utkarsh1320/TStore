import os

AWS_ACCESS_KEY_ID = str(os.environ.get('AWS_ACCESS_KEY_ID'))
AWS_SECRET_ACCESS_KEY = str(os.environ.get('AWS_SECRET_ACCESS_KEY'))
AWS_SESSION_TOKEN = str(os.environ.get('AWS_SESSION_TOKEN'))